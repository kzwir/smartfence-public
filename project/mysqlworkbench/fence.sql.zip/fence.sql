-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: mariadb
-- Czas generowania: 17 Sty 2023, 11:45
-- Wersja serwera: 10.4.8-MariaDB-1:10.4.8+maria~bionic
-- Wersja PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `fence`
--

DELIMITER $$
--
-- Procedury
--
CREATE DEFINER=`admin`@`%` PROCEDURE `drop_alltables` ()   begin
DELETE FROM photovoltaics;
DELETE FROM enter;
DELETE FROM modul;
DELETE FROM message;
DELETE FROM central;
DELETE FROM log;
DELETE FROM msglog;
end$$

CREATE DEFINER=`admin`@`%` PROCEDURE `populate_message` (IN `p_centralId` VARCHAR(17) CHARSET utf8, IN `p_centralName` VARCHAR(100) CHARSET utf8, IN `p_messageTypeId` ENUM('1','A','B','C','D','E','F','G'), IN `p_messageDate` DATETIME, IN `p_moduleName` VARCHAR(100) CHARSET utf8, IN `p_moduleId` VARCHAR(17) CHARSET utf8, IN `p_power` DECIMAL(5,2), IN `p_voltage` DECIMAL(5,2), IN `p_amperage` DECIMAL(5,2), IN `p_messageTxt` VARCHAR(100) CHARSET utf8)   BEGIN
/*
Rodzaje komunikatów:
1 komunikaty o produkcji fotowoltaiki
2 komunikaty bezpieczeństwa
A komunikat o wejściu na teren brelokiem RFID
B komunikat o wejściu na teren po rozpoznaniu twarzy
C rozbrojenie alarmu
D uzbrojenie alarmu
E utrata energii - przejście na zasilanie bateryjne
F uruchomienie urządzenia
G włamanie

Składowe ramek									
1 Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (1)	Data RRRR/MM/DD/hh24/mi/ss	# Nazwa Modułu	* ID Modułu	Moc	Napięcie 	Prąd
A Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (A)	Data RRRR/MM/DD/hh24/mi/ss	# Nazwa Modułu	* ID Modułu	Nazwa breloka RFID		
B Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (B)	Data RRRR/MM/DD/hh24/mi/ss	# Nazwa Modułu	* ID Modułu	Nazwa rozpoznanej twarzy		
C Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (C)	Data RRRR/MM/DD/hh24/mi/ss					
D Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (D)	Data RRRR/MM/DD/hh24/mi/ss					
E Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (E)	Data RRRR/MM/DD/hh24/mi/ss					
F Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (F)	Data RRRR/MM/DD/hh24/mi/ss					
G Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (G)	Data RRRR/MM/DD/hh24/mi/ss	# Nazwa Modułu	* ID Modułu			

Przykładowe ramki									
1 CentralaMC;30:AE:A4:07:0D:64;1;2022/11/15/19/14/2;Plot1;30:AE:B4:08:AD:64;53,0;25,0;1,5;								
A CentralaPS;30:AE:A4:07:0D:64;A;2022/09/11/19/8/8;Bramofon2;30:AE:B4:08:AD:64;brelok1;								
B MojaCentrala;30:AE:A4:07:0D:64;A;2022/09/11/19/8/8;Bramofon2;30:AE:B4:08:AD:64;Twarzyczka1;								
C Centralna;30:AE:A4:07:0D:64;A;2022/09/11/1/8/8;								
D CentralaMC;30:AE:A4:07:0D:64;A;2022/09/8/0/8/8;								
E CentralaMC;30:AE:A4:07:0D:64;A;2022/09/11/19/59/8;								
F CentralaMC;30:AE:A4:07:0D:64;A;2022/09/14/5/8/8;								
G CentralaMC;30:AE:A4:07:0D:64;A;2022/09/11/19/8/8;PodLasem;30:AE:B4:08:AD:64;								

Wszystkie powyższe dane będą przesyłane w formie zmiennej tekstowej.									
Oznaczenie * unikalne- bez możliwości zmiany								
Oznaczenie # możliwość zmiany								
Data będzie znacznikiem z której godziny jest dany pomiar - pomiary uśredniane są przez 30 s i do centrali wysyłany jest komunikat średniej mocy, prądu, napięcia za ostatnie 30s. Centrala po zebraniu wszystkich pomiarów z modułów prześlę poszczególne wyniki do serwera. 									
*/

DECLARE messageId INT;

INSERT INTO msglog(`centralid`,`centralname`,`msgdate`,`messagetype`,`modulename`,`moduleid`,`msgpower`,`voltage`,`amperage`,`msgtxt`) VALUES (p_centralId, p_centralName, p_messageDate, p_messageTypeId, p_moduleName, p_moduleId, p_power, p_voltage, p_amperage, p_messageTxt);

IF (SELECT COUNT(*) FROM central WHERE id_central = p_centralId AND name_central = p_centralName) = 0 THEN
	INSERT INTO central(id_central, name_central) VALUES (p_centralId, p_centralName);
END IF;
  
SELECT id_message into messageId FROM message WHERE id_central = p_centralId AND name_central = p_centralName AND msg_date = p_messageDate AND message_type_id = p_messageTypeId;
IF (messageId IS NULL OR messageId = 0) THEN
	INSERT INTO message(id_message, msg_date, message_type_id, name_central, id_central) VALUES (DEFAULT, p_messageDate, p_messageTypeId, p_centralName, p_centralId);
	SELECT id_message into messageId FROM message WHERE id_central = p_centralId AND name_central = p_centralName AND msg_date = p_messageDate AND message_type_id = p_messageTypeId;
END IF;

CASE 
	WHEN p_messageTypeId = '1' THEN 
		IF ( (SELECT count(*) FROM photovoltaics WHERE message_id = messageId) = 0) THEN
			INSERT INTO photovoltaics (id_photovoltaics, ph_power, voltage, amperage, message_id) VALUES(DEFAULT, p_power, p_voltage, p_amperage, messageId);
            IF ( (SELECT count(*) FROM modul WHERE message_id = messageId) = 0) THEN
				INSERT INTO modul (id, id_module, name_module, message_id) VALUES(DEFAULT, p_moduleId, p_moduleName, messageId);
			END IF;
		END IF;
	WHEN p_messageTypeId = 'A' OR p_messageTypeId = 'B' THEN
		IF ( (SELECT count(*) FROM enter WHERE message_id = messageId) = 0) THEN
           INSERT INTO enter (id_enter, label_enter, message_id) VALUES(DEFAULT, p_messageTxt, messageId);
            IF ( (SELECT count(*) FROM modul WHERE message_id = messageId) = 0) THEN
				INSERT INTO modul (id, id_module, name_module, message_id) VALUES(DEFAULT, p_moduleId, p_moduleName, messageId);
			END IF;
		END IF;
	WHEN p_messageTypeId = 'G' THEN
		IF ( (SELECT count(*) FROM modul WHERE message_id = messageId) = 0) THEN
			INSERT INTO modul (id, id_module, name_module, message_id) VALUES(DEFAULT, p_moduleId, p_moduleName, messageId);
		END IF;
	ELSE
		BEGIN
        END;
END CASE;
	COMMIT;
END$$

CREATE DEFINER=`admin`@`%` PROCEDURE `populate_message_old` (IN `p_centralId` VARCHAR(17) CHARSET utf8, IN `p_centralName` VARCHAR(100) CHARSET utf8, IN `p_messageTypeId` ENUM('1','A','B','C','D','E','F','G'), IN `p_messageDate` DATETIME, IN `p_moduleName` VARCHAR(100) CHARSET utf8, IN `p_moduleId` VARCHAR(17) CHARSET utf8, IN `p_power` DECIMAL(5,2), IN `p_voltage` DECIMAL(5,2), IN `p_amperage` DECIMAL(5,2), IN `p_messageTxt` VARCHAR(100) CHARSET utf8)   BEGIN
/*
Rodzaje komunikatów:
1 komunikaty o produkcji fotowoltaiki
2 komunikaty bezpieczeństwa
A komunikat o wejściu na teren brelokiem RFID
B komunikat o wejściu na teren po rozpoznaniu twarzy
C rozbrojenie alarmu
D uzbrojenie alarmu
E utrata energii - przejście na zasilanie bateryjne
F uruchomienie urządzenia
G włamanie

Składowe ramek									
1 Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (1)	Data RRRR/MM/DD/hh24/mi/ss	# Nazwa Modułu	* ID Modułu	Moc	Napięcie 	Prąd
A Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (A)	Data RRRR/MM/DD/hh24/mi/ss	# Nazwa Modułu	* ID Modułu	Nazwa breloka RFID		
B Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (B)	Data RRRR/MM/DD/hh24/mi/ss	# Nazwa Modułu	* ID Modułu	Nazwa rozpoznanej twarzy		
C Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (C)	Data RRRR/MM/DD/hh24/mi/ss					
D Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (D)	Data RRRR/MM/DD/hh24/mi/ss					
E Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (E)	Data RRRR/MM/DD/hh24/mi/ss					
F Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (F)	Data RRRR/MM/DD/hh24/mi/ss					
G Nazwa Centrali	* ID Centrali	Rodzaj komunikatu (G)	Data RRRR/MM/DD/hh24/mi/ss	# Nazwa Modułu	* ID Modułu			

Przykładowe ramki									
1 CentralaMC;30:AE:A4:07:0D:64;1;2022/11/15/19/14/2;Plot1;30:AE:B4:08:AD:64;53,0;25,0;1,5;								
A CentralaPS;30:AE:A4:07:0D:64;A;2022/09/11/19/8/8;Bramofon2;30:AE:B4:08:AD:64;brelok1;								
B MojaCentrala;30:AE:A4:07:0D:64;A;2022/09/11/19/8/8;Bramofon2;30:AE:B4:08:AD:64;Twarzyczka1;								
C Centralna;30:AE:A4:07:0D:64;A;2022/09/11/1/8/8;								
D CentralaMC;30:AE:A4:07:0D:64;A;2022/09/8/0/8/8;								
E CentralaMC;30:AE:A4:07:0D:64;A;2022/09/11/19/59/8;								
F CentralaMC;30:AE:A4:07:0D:64;A;2022/09/14/5/8/8;								
G CentralaMC;30:AE:A4:07:0D:64;A;2022/09/11/19/8/8;PodLasem;30:AE:B4:08:AD:64;								

Wszystkie powyższe dane będą przesyłane w formie zmiennej tekstowej.									
Oznaczenie * unikalne- bez możliwości zmiany								
Oznaczenie # możliwość zmiany								
Data będzie znacznikiem z której godziny jest dany pomiar - pomiary uśredniane są przez 30 s i do centrali wysyłany jest komunikat średniej mocy, prądu, napięcia za ostatnie 30s. Centrala po zebraniu wszystkich pomiarów z modułów prześlę poszczególne wyniki do serwera. 									
*/

DECLARE messageId INT;
 -- INSERT IGNORE INTO central(id_central, name_central) VALUES (p_centralId, p_centralName);
 
 INSERT INTO msglog(`centralid`,`centralname`,`msgdate`,`messagetype`,`modulename`,`moduleid`,`msgpower`,`voltage`,`amperage`,`msgtxt`) VALUES (p_centralId, p_centralName, p_messageDate, p_messageTypeId, p_moduleName, p_moduleId, p_power, p_voltage, p_amperage, p_messageTxt);
 
 -- SELECT COUNT(*) into messageId FROM central WHERE id_central = p_centralId AND name_central = p_centralName;
 -- insert into log(id, name, value) values (default, 'messageId 1', messageId);
 IF (SELECT COUNT(*) FROM central WHERE id_central = p_centralId AND name_central = p_centralName) = 0 THEN
	INSERT INTO central(id_central, name_central) VALUES (p_centralId, p_centralName);
  END IF;

 -- messageTypeId = 'C' or 'D' or 'E' or 'F'
 -- INSERT IGNORE INTO message(id_message, msg_date, message_type_id, name_central, id_central) VALUES (DEFAULT, p_messageDate, p_messageTypeId, p_centralName, p_centralId);
 SELECT id_message into messageId FROM message WHERE id_central = p_centralId AND name_central = p_centralName AND msg_date = p_messageDate AND message_type_id = p_messageTypeId;
  IF (messageId IS NULL OR messageId = 0) THEN
	insert into log(id, name, value) values (default, 'messageId is null', 0);
	INSERT INTO message(id_message, msg_date, message_type_id, name_central, id_central) VALUES (DEFAULT, p_messageDate, p_messageTypeId, p_centralName, p_centralId);
    SELECT id_message into messageId FROM message WHERE id_central = p_centralId AND name_central = p_centralName AND msg_date = p_messageDate AND message_type_id = p_messageTypeId;
  END IF;

-- SET messageId = LAST_INSERT_ID();
insert into log(id, name, value) values (default, 'messageId przed case', messageId);
insert into log(id, name, value) values (default, 'p_messageTypeId', p_messageTypeId);

CASE 
	WHEN p_messageTypeId = '1' THEN 
		IF ( (SELECT count(*) FROM photovoltaics WHERE message_id = messageId) = 0) then
			INSERT INTO photovoltaics (id_photovoltaics, ph_power, voltage, amperage, message_id) VALUES(DEFAULT, p_power, p_voltage, p_amperage, messageId);
            IF ( (SELECT count(*) FROM modul WHERE message_id = messageId) = 0) then
				INSERT INTO modul (id, id_module, name_module, message_id) VALUES(DEFAULT, p_moduleId, p_moduleName, messageId);
			END IF;
		END IF;
	WHEN p_messageTypeId = 'A' OR p_messageTypeId = 'B' THEN
		IF ( (SELECT count(*) FROM enter WHERE message_id = messageId) = 0) then
			-- INSERT IGNORE INTO enter (id_enter, label_enter, message_id) VALUES(DEFAULT, p_messageTxt, @messageId);
			-- INSERT IGNORE INTO modul (id, id_module, name_module, message_id) VALUES(DEFAULT, p_moduleId, p_moduleName, @messageId);
            INSERT INTO enter (id_enter, label_enter, message_id) VALUES(DEFAULT, p_messageTxt, messageId);
            IF ( (SELECT count(*) FROM modul WHERE message_id = messageId) = 0) then
				INSERT INTO modul (id, id_module, name_module, message_id) VALUES(DEFAULT, p_moduleId, p_moduleName, messageId);
			END IF;
		END IF;
	WHEN p_messageTypeId = 'G' THEN
		IF ( (SELECT count(*) FROM modul WHERE message_id = messageId) = 0) then
			INSERT INTO modul (id, id_module, name_module, message_id) VALUES(DEFAULT, p_moduleId, p_moduleName, messageId);
		END IF;
	else
		begin
        end;
END CASE;

	commit;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `central`
--

CREATE TABLE `central` (
  `id_central` varchar(17) NOT NULL,
  `name_central` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `enter`
--

CREATE TABLE `enter` (
  `id_enter` int(11) NOT NULL,
  `label_enter` varchar(100) NOT NULL,
  `message_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `message`
--

CREATE TABLE `message` (
  `id_message` int(11) NOT NULL,
  `msg_date` datetime NOT NULL,
  `message_type_id` enum('1','A','B','C','D','E','F','G') NOT NULL,
  `name_central` varchar(100) NOT NULL,
  `id_central` varchar(17) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `message_type`
--

CREATE TABLE `message_type` (
  `id_message_type` enum('1','A','B','C','D','E','F','G') NOT NULL,
  `label` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `message_type`
--

INSERT INTO `message_type` (`id_message_type`, `label`) VALUES
('1', 'komunikat o produkcji fotowoltaiki'),
('A', 'komunikat o wejsciu na teren brelokiem RFID'),
('B', 'komunikat o wejsciu na teren po rozpoznaniu twarzy'),
('C', 'rozbrojenie alarmu'),
('D', 'uzbrojenie alarmu'),
('E', 'utrata energii - przejscie na zasilanie bateryjne'),
('F', 'uruchomienie urzadzenia  '),
('G', 'wlamanie ');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `modul`
--

CREATE TABLE `modul` (
  `id` int(11) NOT NULL,
  `id_module` varchar(17) NOT NULL,
  `name_module` varchar(100) NOT NULL,
  `message_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `msglog`
--

CREATE TABLE `msglog` (
  `centralid` varchar(17) DEFAULT NULL,
  `centralname` varchar(100) DEFAULT NULL,
  `msgdate` datetime DEFAULT NULL,
  `messagetype` varchar(1) DEFAULT NULL,
  `modulename` varchar(100) DEFAULT NULL,
  `moduleid` varchar(17) DEFAULT NULL,
  `msgpower` decimal(5,2) DEFAULT NULL,
  `voltage` decimal(5,2) DEFAULT NULL,
  `amperage` decimal(5,2) DEFAULT NULL,
  `msgtxt` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `photovoltaics`
--

CREATE TABLE `photovoltaics` (
  `id_photovoltaics` int(11) NOT NULL,
  `ph_power` decimal(5,2) NOT NULL,
  `voltage` decimal(5,2) NOT NULL,
  `amperage` decimal(5,2) NOT NULL,
  `message_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `central`
--
ALTER TABLE `central`
  ADD PRIMARY KEY (`name_central`,`id_central`);

--
-- Indeksy dla tabeli `enter`
--
ALTER TABLE `enter`
  ADD PRIMARY KEY (`id_enter`,`message_id`),
  ADD KEY `fk_enter_message_idx` (`message_id`);

--
-- Indeksy dla tabeli `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id_message`,`message_type_id`,`name_central`,`id_central`),
  ADD UNIQUE KEY `unique_index` (`msg_date`,`id_central`,`name_central`),
  ADD KEY `fk_message_message_type_idx` (`message_type_id`),
  ADD KEY `fk_message_central_idx` (`name_central`,`id_central`) USING BTREE;

--
-- Indeksy dla tabeli `message_type`
--
ALTER TABLE `message_type`
  ADD PRIMARY KEY (`id_message_type`);

--
-- Indeksy dla tabeli `modul`
--
ALTER TABLE `modul`
  ADD PRIMARY KEY (`id`,`message_id`),
  ADD KEY `fk_modul_message_idx` (`message_id`);

--
-- Indeksy dla tabeli `photovoltaics`
--
ALTER TABLE `photovoltaics`
  ADD PRIMARY KEY (`id_photovoltaics`,`message_id`),
  ADD KEY `fk_photovoltaics_message_idx` (`message_id`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `enter`
--
ALTER TABLE `enter`
  MODIFY `id_enter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT dla tabeli `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=354;

--
-- AUTO_INCREMENT dla tabeli `message`
--
ALTER TABLE `message`
  MODIFY `id_message` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=245;

--
-- AUTO_INCREMENT dla tabeli `modul`
--
ALTER TABLE `modul`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT dla tabeli `photovoltaics`
--
ALTER TABLE `photovoltaics`
  MODIFY `id_photovoltaics` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=195;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `enter`
--
ALTER TABLE `enter`
  ADD CONSTRAINT `fk_enter_message` FOREIGN KEY (`message_id`) REFERENCES `message` (`id_message`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ograniczenia dla tabeli `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `fk_message_central1` FOREIGN KEY (`name_central`,`id_central`) REFERENCES `central` (`name_central`, `id_central`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_message_message_type` FOREIGN KEY (`message_type_id`) REFERENCES `message_type` (`id_message_type`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ograniczenia dla tabeli `modul`
--
ALTER TABLE `modul`
  ADD CONSTRAINT `fk_modul_message` FOREIGN KEY (`message_id`) REFERENCES `message` (`id_message`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ograniczenia dla tabeli `photovoltaics`
--
ALTER TABLE `photovoltaics`
  ADD CONSTRAINT `fk_photovoltaics_message` FOREIGN KEY (`message_id`) REFERENCES `message` (`id_message`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
